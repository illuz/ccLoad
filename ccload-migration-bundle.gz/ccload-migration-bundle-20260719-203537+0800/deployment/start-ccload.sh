#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
set -a
. ./.env
set +a
exec ./bin/ccload
