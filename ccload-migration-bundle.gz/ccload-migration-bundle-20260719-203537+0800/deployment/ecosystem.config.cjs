module.exports = {
  apps: [
    {
      name: "ccload",
      cwd: __dirname,
      script: "./start-ccload.sh",
      interpreter: "none",
      exec_mode: "fork",
      autorestart: true,
      watch: false,
      min_uptime: "10s",
      max_restarts: 10,
      restart_delay: 3000,
      out_file: "./logs/ccload.log",
      error_file: "./logs/ccload.error.log",
      merge_logs: true,
      time: true,
    },
  ],
};
