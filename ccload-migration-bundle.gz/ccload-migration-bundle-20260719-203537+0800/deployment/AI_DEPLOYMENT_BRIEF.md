# ccLoad Target Deployment Brief

This bundle moves the active ccLoad instance configuration to another machine. It is sensitive: the nested configuration archive contains upstream API keys, client access tokens, and the current administrator password. Do not store it in a repository or send it over an untrusted channel.

## Source deployment snapshot

- OS/architecture: Debian 11 (bullseye), Linux x86_64
- ccLoad binary: `/usr/local/bin/ccload`
- Active binary version: `v2.30.0-106-gd9e2b13`, built 2026-07-16 12:43:52 +0800
- Runtime directory: `/root/workspace/ccload-runtime`
- Process manager: PM2 5.3.0, application name `ccload`, fork mode, auto-restart enabled, file watching disabled
- Process working directory: `/root/workspace/ccload-runtime`
- Listen address: `*:18422` (plain HTTP; no reverse-proxy configuration is part of this bundle)
- Storage: SQLite only, with `SQLITE_PATH=./data/ccload.db`
- Non-secret environment keys: `PORT=18422`, `GIN_MODE=release`, `TZ=Asia/Shanghai`, `GIN_LOG`, `CCLOAD_MAX_BODY_BYTES`
- Runtime logs: `logs/ccload.log` and `logs/ccload.error.log`
- Current service footprint: ccLoad about 313 MiB RSS at export time

The source also has a PM2 process named `ccload-debug-analyzer`, which runs `scripts/analyze_debug_logs.py --follow`. It is intentionally excluded and should not be started on the target until debug log capture and its storage requirements have been explicitly planned.

A legacy `ccload.service` systemd unit exists on the source but is disabled and inactive. Do not reproduce it; use the supplied PM2 files so there is only one process manager for ccLoad.

## Configuration contents

`config/ccload-config-20260719-203108+0800.tar.gz` contains:

- 39 channels, 44 upstream API keys, 327 channel-model mappings, 60 protocol transforms
- 5 channel groups, 5 token groups, 43 client access tokens, 28 system settings
- a portable `.env` equivalent (`ccload.env`) and a SQLite database (`ccload.db`)

It deliberately excludes all normal logs, raw debug logs, admin sessions, token usage statistics, and temporary cooldown state. The source SQLite database was about 34 GiB and its debug-analysis directory about 60 GiB; neither is included. The exported database is about 272 KiB and has empty log tables.

## Required target procedure

Use a source checkout at the exact source binary commit `d9e2b13` to reproduce the current behavior. A newer compatible ccLoad version is also acceptable, but never use an older version. The target must use SQLite, not MySQL, for this import.

1. Choose a runtime directory independent of the source checkout. In the commands below, set `PROJECT_DIR` to the already-downloaded project and `RUNTIME_DIR` to its data/runtime directory.
2. Build the target binary into `RUNTIME_DIR/bin/ccload` using the project Makefile. The target needs Go and the dependencies already prepared.
3. Extract the nested configuration archive, verify its internal checksums, and install `ccload.db` plus `ccload.env` into the runtime directory. Change `PORT` only if 18422 is unavailable. Keep `SQLITE_PATH=./data/ccload.db` when the PM2 working directory is `RUNTIME_DIR`.
4. Install the supplied PM2 wrapper and ecosystem file into `RUNTIME_DIR`, start it with PM2, then save the PM2 process list.
5. Confirm `http://127.0.0.1:18422/health` responds successfully before exposing the service through a firewall or reverse proxy.

Example commands for the target AI/operator:

```bash
export PROJECT_DIR=/opt/ccLoad
export RUNTIME_DIR=/opt/ccload-runtime
export BUNDLE=/path/to/THIS_BUNDLE.tar.gz

mkdir -p "$RUNTIME_DIR"/{bin,data,logs}
tar -xzf "$BUNDLE" -C /tmp
BUNDLE_DIR=$(tar -tzf "$BUNDLE" | head -1 | cut -d/ -f1)
export BUNDLE_DIR=/tmp/$BUNDLE_DIR

(cd "$BUNDLE_DIR" && sha256sum -c SHA256SUMS)
tar -xzf "$BUNDLE_DIR/config/ccload-config-20260719-203108+0800.tar.gz" -C /tmp
CONFIG_DIR=$(tar -tzf "$BUNDLE_DIR/config/ccload-config-20260719-203108+0800.tar.gz" | head -1 | cut -d/ -f1)
export CONFIG_DIR=/tmp/$CONFIG_DIR
(cd "$CONFIG_DIR" && sha256sum -c SHA256SUMS)

# Match source behavior when that commit is available; otherwise use a newer compatible checkout.
cd "$PROJECT_DIR"
git checkout d9e2b13
make build BINARY_NAME="$RUNTIME_DIR/bin/ccload"

# Stop any old ccLoad instance before replacing its database.
pm2 delete ccload 2>/dev/null || true
install -m 600 "$CONFIG_DIR/ccload.db" "$RUNTIME_DIR/data/ccload.db"
install -m 600 "$CONFIG_DIR/ccload.env" "$RUNTIME_DIR/.env"
rm -f "$RUNTIME_DIR/data/ccload.db-wal" "$RUNTIME_DIR/data/ccload.db-shm"
install -m 755 "$BUNDLE_DIR/deployment/start-ccload.sh" "$RUNTIME_DIR/start-ccload.sh"
install -m 600 "$BUNDLE_DIR/deployment/ecosystem.config.cjs" "$RUNTIME_DIR/ecosystem.config.cjs"

# Review only machine-specific choices before launch: PORT, CCLOAD_PASS, and SQLITE_PATH.
# Do not print or commit .env because it contains secrets.
pm2 start "$RUNTIME_DIR/ecosystem.config.cjs" --only ccload
pm2 save
curl --fail http://127.0.0.1:18422/health
pm2 show ccload
```

If the target uses a non-root deployment user, make `PROJECT_DIR`, `RUNTIME_DIR`, PM2, and all installed files owned by that same user. Configure firewall and reverse proxy separately. Run `pm2 startup` and execute the command it prints if PM2 should survive host reboots.
